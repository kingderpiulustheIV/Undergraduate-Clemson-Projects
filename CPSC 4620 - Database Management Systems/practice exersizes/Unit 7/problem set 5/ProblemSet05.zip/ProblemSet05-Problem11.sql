-- ## Problem 11
-- 
-- Write a query to display the author ID, first and last name for all authors who have never 
-- written a book with the subject Programming. Sort the results by author last name.
-- 
-- +---------+------------+------------+
-- |   AU_ID | AU_FNAME   | AU_LNAME   |
-- |---------+------------+------------|
-- |     581 | Manish     | Aggerwal   |
-- |     251 | Hugo       | Bruer      |
-- |     262 | Xia        | Chiang     |
-- |     438 | Perry      | Pearson    |
-- |     284 | Trina      | Tankersly  |
-- |     383 | Neal       | Walsh      |
-- +---------+------------+------------+
-- 

/* YOUR SOLUTION HERE */

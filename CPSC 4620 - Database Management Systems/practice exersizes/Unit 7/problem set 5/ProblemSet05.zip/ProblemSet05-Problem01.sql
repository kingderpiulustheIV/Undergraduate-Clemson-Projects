-- ## Problem 1
-- 
-- Write a query to display the author ID, first and last name, book number, and book title of 
-- all books in the subject "Cloud". Sort the results by book title and then by author last name.
-- 
-- +---------+------------+------------+------------+---------------------------------+
-- |   AU_ID | AU_FNAME   | AU_LNAME   |   BOOK_NUM | BOOK_TITLE                      |
-- |---------+------------+------------+------------+---------------------------------|
-- |     251 | Hugo       | Bruer      |       5246 | Capture the Cloud               |
-- |     262 | Xia        | Chiang     |       5244 | Cloud-based Mobile Applications |
-- |     284 | Trina      | Tankersly  |       5244 | Cloud-based Mobile Applications |
-- |     383 | Neal       | Walsh      |       5236 | Database in the Cloud           |
-- |     262 | Xia        | Chiang     |       5249 | Starlight Applications          |
-- +---------+------------+------------+------------+---------------------------------+
-- 

/* YOUR SOLUTION HERE */

-- ## Problem 13
-- 
-- Write a query to display the book number, title, subject, author last name, and the number of 
-- books written by that author. Limit the results to books in the Cloud subject. 
-- Sort the results by book title and then author last name.
-- 
-- +------------+---------------------------------+----------------+------------+-----------------------+
-- |   BOOK_NUM | BOOK_TITLE                      | BOOK_SUBJECT   | AU_LNAME   |   Num Books by Author |
-- |------------+---------------------------------+----------------+------------+-----------------------|
-- |       5246 | Capture the Cloud               | Cloud          | Bruer      |                     2 |
-- |       5244 | Cloud-based Mobile Applications | Cloud          | Chiang     |                     3 |
-- |       5244 | Cloud-based Mobile Applications | Cloud          | Tankersly  |                     1 |
-- |       5236 | Database in the Cloud           | Cloud          | Walsh      |                     2 |
-- |       5249 | Starlight Applications          | Cloud          | Chiang     |                     3 |
-- +------------+---------------------------------+----------------+------------+-----------------------+
-- 

/* YOUR SOLUTION HERE */

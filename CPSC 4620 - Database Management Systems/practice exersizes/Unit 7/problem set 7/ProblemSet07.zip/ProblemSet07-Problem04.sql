-- ## Problem 4
-- 
-- Write a query to display the largest average product price of any brand.
-- 
-- Your results should look like this:
-- +-------------------+
-- |   LARGEST AVERAGE |
-- |-------------------|
-- |             22.59 |
-- +-------------------+
-- 

/* YOUR SOLUTION HERE */


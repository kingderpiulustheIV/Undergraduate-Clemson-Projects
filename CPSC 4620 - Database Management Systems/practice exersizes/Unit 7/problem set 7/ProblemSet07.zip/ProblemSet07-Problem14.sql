-- ## Problem 14
-- 
-- The purchasing manager is still concerned about the impact of price on sales. Write a query to
-- display the brand name, brand type, product SKU, product description, and price of any products
-- that are not a premium brand, but that cost more than the most expensive premium brand products.
-- 
-- Your results should look like this:
-- +--------------+--------------+------------+--------------------------------------------+--------------+
-- | BRAND_NAME   | BRAND_TYPE   | PROD_SKU   | PROD_DESCRIPT                              |   PROD_PRICE |
-- |--------------+--------------+------------+--------------------------------------------+--------------|
-- | LONG HAUL    | CONTRACTOR   | 1964-OUT   | Fire Resistant Top Coat, for Interior Wood |        78.49 |
-- +--------------+--------------+------------+--------------------------------------------+--------------+
-- 

/* YOUR SOLUTION HERE */


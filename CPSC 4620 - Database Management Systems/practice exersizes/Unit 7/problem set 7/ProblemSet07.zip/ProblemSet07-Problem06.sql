-- ## Problem 6
-- 
-- Write a query to display the manager name, department name, department phone number, employee name,
-- customer name, invoice date, and invoice total for the department manager of the employee who made
-- a sale to a customer whose last name is Hagan on May 18, 2021.
-- 
-- Your results should look like this:
-- +-------------+-------------+-------------+--------------+-------------+-------------+--------------+--------------+------------+-------------+
-- | EMP_FNAME   | EMP_LNAME   | DEPT_NAME   | DEPT_PHONE   | EMP_FNAME   | EMP_LNAME   | CUST_FNAME   | CUST_LNAME   | INV_DATE   |   INV_TOTAL |
-- |-------------+-------------+-------------+--------------+-------------+-------------+--------------+--------------+------------+-------------|
-- | FRANKLYN    | STOVER      | SALES       | 555-2824     | THURMAN     | WILKINSON   | DARELL       | HAGAN        | 2021-05-18 |      315.04 |
-- +-------------+-------------+-------------+--------------+-------------+-------------+--------------+--------------+------------+-------------+
-- 

/* YOUR SOLUTION HERE */


-- ## Problem 5
-- 
-- Write a query to display the brand ID, brand name, brand type, and average price of products 
-- for the brand that has the largest average product price.
-- 
-- Your results should look like this:
-- +------------+--------------+--------------+------------+
-- |   BRAND_ID | BRAND_NAME   | BRAND_TYPE   |   AVGPRICE |
-- |------------+--------------+--------------+------------|
-- |         29 | BUSTERS      | VALUE        |      22.59 |
-- +------------+--------------+--------------+------------+
-- 

/* YOUR SOLUTION HERE */


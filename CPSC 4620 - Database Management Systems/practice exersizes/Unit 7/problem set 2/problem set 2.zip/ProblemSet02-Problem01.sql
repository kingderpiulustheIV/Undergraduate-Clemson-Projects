-- ## Problem 1
-- 
-- Write a query to count the number of invoices.
-- 
-- +----------+
-- | COUNT(*) |
-- +----------+
-- |    8     |
-- +----------+
-- 
/* YOUR SOLUTION HERE */
SELECT 
	COUNT(*) 
FROM 
	INVOICE;
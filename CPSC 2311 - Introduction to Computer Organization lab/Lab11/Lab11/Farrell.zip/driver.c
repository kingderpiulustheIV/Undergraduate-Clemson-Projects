/*************************
* Sean Farrell
* CPSC 2310 Lab Section 5
* spfarre@g.clemson.edu
*************************/
#include <stdio.h>
int main(){
        int min = 0;
        int max = 10;
        for(int i = 0; i <= max; i++){
                printf("%d", i);
        }
        printf("\n");
        return 0;
}
// Sean Farrell
// CPSC 4040 Tessendorf
// Assignment 1
// 9/11/2025
#ifndef OIIOSTUFF
#define OIIOSTUFF

void simple_write();
void simple_read();
#endif
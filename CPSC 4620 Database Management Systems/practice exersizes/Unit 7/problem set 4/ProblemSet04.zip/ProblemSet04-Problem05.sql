-- ## Problem 5
-- Write a query to display the number of books that are available (not currently checked out).
-- 
-- +-----------------+
-- | Available Books |
-- +-----------------+
-- |       14        |
-- +-----------------+

/* YOUR SOLUTION HERE */


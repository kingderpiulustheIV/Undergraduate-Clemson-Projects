-- ## Problem 13
-- 
-- Using a single SQL command with the EMP_2 table, write the SQL code that will change the
-- project number (PROJ_NUM) to 18 for all employees whose job classification (JOB_CODE) is 500.
--

/* YOUR SOLUTION HERE */


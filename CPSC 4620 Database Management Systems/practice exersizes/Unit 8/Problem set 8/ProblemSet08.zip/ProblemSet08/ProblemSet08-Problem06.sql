-- ## Problem 6
-- 
-- Using the EMP_1 table, write the SQL code to delete the row for William Smithfield, who was hired on June 22, 2004, and whose job code is 500.
-- 
-- NOTE: Use logical operators to include all of the information given in this problem. 
-- Remember, if you are using MySQL, you may have to first disable “safe mode.”
--

/* YOUR SOLUTION HERE */


-- ## Problem 3
-- 
-- Using the EMPLOYEE table that already exists, use a subquery to insert the remaining rows 
-- from the EMPLOYEE table into the EMP_1 table. Remember, your subquery should only retrieve the
-- data for employees 103 through 109.
-- 

/* YOUR SOLUTION HERE */


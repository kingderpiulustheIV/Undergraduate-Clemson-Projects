-- ## Problem 4
-- 
-- Write the SQL code that will save the changes made to the EMP_1 table
-- [assuming you had wrapped your insert with a TRANSACTION].
-- 

/* YOUR SOLUTION HERE */
COMMIT;

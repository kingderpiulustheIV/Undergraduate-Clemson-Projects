-- ## Problem 5
-- 
-- Write the SQL code to change the job code to 501 for the person whose 
-- employee number (EMP_NUM) is 107.
--

/* YOUR SOLUTION HERE */
UPDATE EMP_1
SET JOB_CODE = '501'
WHERE EMP_NUM = '107';

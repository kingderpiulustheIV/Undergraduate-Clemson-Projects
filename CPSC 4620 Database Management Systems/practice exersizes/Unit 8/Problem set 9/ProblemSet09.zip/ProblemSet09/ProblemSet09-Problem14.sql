-- ## Problem 14
-- 
-- Write a trigger to update the CUST_BALANCE when an invoice is deleted. 
-- Name the trigger trg_updatecustbalance2.
-- 
-- You should delete INV_NUM 9006 from INVOICE and look at results for the customer
-- data associated with that invoice to to ensure your code is correct.
--
-- Make sure you include the appropriate DELIMITER statements in your solution! 
-- 

/* YOUR SOLUTION HERE */


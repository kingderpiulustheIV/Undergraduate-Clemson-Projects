-- ## Problem 5
-- 
-- Enable auto increment on the primary key in the CUSTOMER table.
-- The values should start with 2000.
-- 

/* YOUR SOLUTION HERE */


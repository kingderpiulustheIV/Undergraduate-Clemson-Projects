-- ## Problem 9
-- 
-- Update customer 1000 to have a date of birth on March 15, 1989.
-- 
-- NOTE: Use YYYY-MM-DD format for date values.
--

/* YOUR SOLUTION HERE */


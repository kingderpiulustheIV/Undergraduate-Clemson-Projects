-- ## Problem 10
-- 
-- Modify customer 1001 to have a date of birth on December 22, 1988.
-- 
-- NOTE: Use YYYY-MM-DD format for date values.
--

/* YOUR SOLUTION HERE */


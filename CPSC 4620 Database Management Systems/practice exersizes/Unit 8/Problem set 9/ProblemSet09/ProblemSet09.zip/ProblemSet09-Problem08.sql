-- ## Problem 8
-- 
-- Modify the CUSTOMER table to include the customer’s date of birth (CUST_DOB), 
-- which should store date data
--

/* YOUR SOLUTION HERE */
ALTER TABLE CUSTOMER
ADD COLUMN CUST_DOB DATE;

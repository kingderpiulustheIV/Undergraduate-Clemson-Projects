-- ## Problem 5
-- 
-- Enable auto increment on the primary key in the CUSTOMER table.
-- The values should start with 2000.
-- 

/* YOUR SOLUTION HERE */
-- Temporarily disable foreign key checks
SET FOREIGN_KEY_CHECKS = 0;

-- Enable auto increment on the primary key in the CUSTOMER table
ALTER TABLE CUSTOMER 
MODIFY CUST_NUM INTEGER AUTO_INCREMENT;

-- Set the auto increment value to start at 2000
ALTER TABLE CUSTOMER AUTO_INCREMENT = 2000;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;